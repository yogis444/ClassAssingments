package com.scvene;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.GenericServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/register")
public class RegisterServlet extends GenericServlet implements Servlet {
	Connection cn;
	public void init(){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		String uname=request.getParameter("uname");
		String pwd=request.getParameter("pass");
		String name=request.getParameter("fname");
		String email=request.getParameter("email");
		String phone=request.getParameter("mobile");
		String SQA=request.getParameter("q");
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		try{
			PreparedStatement ps=cn.prepareStatement("insert into user_reg values(?,?,?,?,?,?)");
			ps.setString(1, uname);
			ps.setString(2, pwd);
			ps.setString(3, name);
			ps.setString(4, email);
			ps.setString(6, phone);
			ps.setString(5, SQA);
			ps.executeUpdate();
			RequestDispatcher rd=request.getRequestDispatcher("login.html");
			rd.include(request, response);
			out.println("User is Registred Successfully.......");
		}catch(SQLException e1){
			out.println("Error in user Registration.....");
		}
	}

}
