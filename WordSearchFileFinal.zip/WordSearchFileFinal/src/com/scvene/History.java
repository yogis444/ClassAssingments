package com.scvene;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.GenericServlet;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

/**
 * Servlet implementation class History
 */
@WebServlet("/history")
public class History extends GenericServlet implements Servlet {
	Connection con;
	public void init(){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		try {
			PreparedStatement ps=con.prepareStatement("select * from history");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				String str=rs.getString(1);
			out.println("<html>");
			out.println("<body bgcolor=#DEB887>");
			out.println(str);
			out.println("<br>");
			out.println("------------------");out.println("<br>");
			
			//System.out.println(str);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
