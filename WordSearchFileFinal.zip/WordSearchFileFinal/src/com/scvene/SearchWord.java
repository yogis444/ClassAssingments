package com.scvene;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.servlet.GenericServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

/**
 * Servlet implementation class SearchWord
 */
@WebServlet("/SearchWord")
public class SearchWord extends GenericServlet implements Servlet {
	int count=0;
	private Connection cn;
	public void init(){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		String word=request.getParameter("data");
		//String word="hii";
		PrintWriter out=response.getWriter();
		ArrayList<String>list=new ArrayList<String>();
		//out.println(word);
		//if(request.getParameter(""))
		if(word!=null){
		try{
			long time=System.currentTimeMillis();
			System.out.println(time);
			PreparedStatement ps=cn.prepareStatement("insert into history values(?)");
			//out.println("hi");
			ps.setString(1,word);
			//out.println("hello");
			ps.executeUpdate();
			//out.println("hi");
		}catch(SQLException e){
			e.printStackTrace();
		}
		}
		try{
			PreparedStatement ps=cn.prepareStatement("select address from testdb");
			ResultSet rs=ps.executeQuery();
			 String str;
			while(rs.next()){
				 str=rs.getString(1);
				//System.out.println(str);
				list.add(str);
				for(String e:list){
					//System.out.println(str);
					FileInputStream fis = new FileInputStream(str);
			        @SuppressWarnings("resource")
					String inputStreamString = new Scanner(fis).useDelimiter("\\A").next();
			        //System.out.println(inputStreamString);
			        
			        
//			        String strOrig = "Hello readers";
			        int intIndex = inputStreamString.indexOf(word);
				
			        if(intIndex > - 1){
			        	RequestDispatcher rd=request.getRequestDispatcher("history.html");
						rd.include(request, response);
			        	out.println("Found  "+word+ " at index "
			 	               + intIndex+" in File Name  "+str);
			        	out.println("<br>");
			           return;
			        }else{
			        	
			      //  	out.println(word+"  not found in our database in "+str+"\n");
			        	count++;
			           
			        // System.out.println(inputStreamString);
			           
			        }
				}
			}
			
		} catch (SQLException | FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(count>0){
			RequestDispatcher rd=request.getRequestDispatcher("Keybord.htm");
			rd.include(request, response);
			out.println("word in not found in our database");
		}else{
			return;
		}
		}
		public void history(){
			System.out.println("hiiiii");
			try {
				PreparedStatement ps=cn.prepareStatement("select history from testdb");
				ResultSet rs=ps.executeQuery();
				while(rs.next()){
					String str=rs.getString(1);
					System.out.println(str);
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
 


