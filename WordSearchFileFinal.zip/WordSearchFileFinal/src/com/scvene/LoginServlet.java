package com.scvene;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.GenericServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends GenericServlet implements Servlet {
	private Connection cn;
	public void init(){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		String user=request.getParameter("uname");
		String pwd=request.getParameter("pass");
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		try{
			PreparedStatement ps=cn.prepareStatement("select count(*) from user_reg where uname=? and pwd=?");
			ps.setString(1, user);
			ps.setString(2, pwd);
			ResultSet rs=ps.executeQuery();
			rs.next();
			int c=rs.getInt(1);
			if(c>0){
				out.println("<body bgcolor=cyan><h2>Hello "+user);
				RequestDispatcher rd=request.getRequestDispatcher("Keybord.htm");
				rd.include(request, response);
			}else{
				RequestDispatcher rd=request.getRequestDispatcher("login.html");
				rd.include(request, response);
				out.println("Invalid UserName or Password");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
