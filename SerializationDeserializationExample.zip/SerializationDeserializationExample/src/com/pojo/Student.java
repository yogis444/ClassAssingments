package com.pojo;

import java.io.Serializable;

public class Student implements Serializable {
private int rollno;
private String name;
private String uname;
private String password;
private static final long serialVersionUID = -7588980448693010399L;
public Student() {
	super();
}
public Student(int rollno, String name, String uname, String password) {
	super();
	this.rollno = rollno;
	this.name = name;
	this.uname = uname;
	this.password = password;
}
public int getRollno() {
	return rollno;
}
public void setRollno(int rollno) {
	this.rollno = rollno;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
@Override
public String toString() {
	return "Student [rollno=" + rollno + ", name=" + name + ", uname=" + uname + ", password=" + password + "]";
}
}
