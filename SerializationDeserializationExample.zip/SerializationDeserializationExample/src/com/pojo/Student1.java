/**
 * 
 */
package com.pojo;

import java.io.Serializable;

/**
 * @author yogesh
 *
 */
public class Student1 implements Serializable {
	private int rollno;
	private String name;
	private String uname;
	private String password;
	public int getRollno() {
		return rollno;
	}

	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Student1 [rollno=" + rollno + ", name=" + name + ", uname=" + uname + ", password=" + password + "]";
	}

	public Student1(int rollno, String name, String uname, String password) {
		super();
		this.rollno = rollno;
		this.name = name;
		this.uname = uname;
		this.password = password;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -136397796636218054L;

	/**
	 * 
	 */
	public Student1() {
		// TODO Auto-generated constructor stub
	}

}
