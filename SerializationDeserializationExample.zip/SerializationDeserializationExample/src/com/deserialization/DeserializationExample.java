package com.deserialization;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

import com.pojo.Student;
import com.pojo.Student1;

public class DeserializationExample {
static Student s=null;
public static void main(String[] args) {
	Student1 s1 = null;
	try {
		FileInputStream fileIn = new FileInputStream("./Student1.txt");
		ObjectInputStream in = new ObjectInputStream(fileIn);
		s1 = (Student1) in.readObject();
		in.close();
		fileIn.close();
	} catch (IOException i) {
		i.printStackTrace();
		return;
	} catch (ClassNotFoundException c) {
		System.out.println("Student class not found");
		c.printStackTrace();
		return;
	}
	System.out.println("Deserializing Employee...");
	System.out.println(s1);
}
}

