package com.serialization;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import com.pojo.Student;
import com.pojo.Student1;

public class SerializationExample {
static Student1 s1=new Student1(101, "xyz", "abc", "abc123");
public static void main(String[] args) {
	try {
		FileOutputStream fos=new FileOutputStream("./Student1.txt");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(s1);
		fos.close();
		oos.close();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
